package com.example.autopark.autopark.controller;

import com.example.autopark.autopark.entity.Role;
import com.example.autopark.autopark.entity.User;
import com.example.autopark.autopark.repository.UserRepository;
import com.example.autopark.autopark.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;

    public AuthController(UserRepository userRepository, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody User user) {
        Optional<User> foundUser = userRepository.findByUsername(user.getUsername());

        if (foundUser.isPresent() && foundUser.get().getPassword().equals(user.getPassword())) {
            // Генерация токена после успешной аутентификации
            String token = jwtUtil.generateToken(foundUser.get().getUsername());
            return ResponseEntity.ok(token); // Возвращаем токен клиенту
        } else {
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }

    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody User user) {
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            return ResponseEntity.badRequest().body("User already exists");
        }

        user.setRole(Role.CUSTOMER); // Устанавливаем роль Customer по умолчанию
        userRepository.save(user);
        return ResponseEntity.ok("User registered successfully");
    }
}