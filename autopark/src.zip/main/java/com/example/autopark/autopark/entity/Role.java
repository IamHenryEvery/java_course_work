package com.example.autopark.autopark.entity;

public enum Role {
    ADMIN,
    CUSTOMER
}
