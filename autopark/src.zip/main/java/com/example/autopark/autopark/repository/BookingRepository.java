package com.example.autopark.autopark.repository;

import com.example.autopark.autopark.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUserId(Long userId);  // Поиск бронирований по пользователю
    List<Booking> findByCarId(Long carId);  // Поиск бронирований по автомобилю
}