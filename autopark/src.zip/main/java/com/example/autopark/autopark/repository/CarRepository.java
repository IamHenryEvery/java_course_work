package com.example.autopark.autopark.repository;

import com.example.autopark.autopark.entity.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CarRepository extends JpaRepository<Car, Long> {
    List<Car> findByAvailableTrue();  // Поиск доступных автомобилей
}