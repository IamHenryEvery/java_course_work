package com.example.autopark.autopark.service;

import com.example.autopark.autopark.entity.Booking;
import com.example.autopark.autopark.entity.Car;
import com.example.autopark.autopark.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private CarRepository carRepository;

    @Autowired
    private UserRepository userRepository;

    public List<Booking> getBookingsByUser(Long userId) {
        return bookingRepository.findByUserId(userId);  // Получение всех бронирований для пользователя
    }

    public List<Booking> getBookingsByCar(Long carId) {
        return bookingRepository.findByCarId(carId);  // Получение всех бронирований для автомобиля
    }

    public void createBooking(Booking booking) {
        // Проверка доступности автомобиля
        Car car = carRepository.findById(booking.getCar().getId()).orElseThrow(() -> new RuntimeException("Car not found"));
        if (!car.isAvailable()) {
            throw new RuntimeException("Car is not available");
        }
        bookingRepository.save(booking);  // Создание нового бронирования
    }

    public void cancelBooking(Long bookingId) {
        bookingRepository.deleteById(bookingId);  // Отмена бронирования
    }
}