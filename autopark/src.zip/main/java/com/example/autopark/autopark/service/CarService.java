package com.example.autopark.autopark.service;

import com.example.autopark.autopark.entity.Car;
import com.example.autopark.autopark.repository.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarService {

    @Autowired
    private CarRepository carRepository;

    public List<Car> getAvailableCars() {
        return carRepository.findByAvailableTrue();  // Получение всех доступных автомобилей
    }

    public void addCar(Car car) {
        carRepository.save(car);  // Добавление нового автомобиля
    }

    public void deleteCar(Long id) {
        carRepository.deleteById(id);  // Удаление автомобиля по ID
    }

    public void updateCar(Car car) {
        carRepository.save(car);  // Обновление данных автомобиля
    }
}