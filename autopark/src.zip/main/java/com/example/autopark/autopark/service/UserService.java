package com.example.autopark.autopark.service;

import com.example.autopark.autopark.entity.User;
import com.example.autopark.autopark.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public Optional<User> getUserByUsername(String username) {
        return userRepository.findByUsername(username);  // Теперь возвращаем Optional<User>
    }

    public void addUser(User user) {
        userRepository.save(user);  // Добавление нового пользователя
    }
}